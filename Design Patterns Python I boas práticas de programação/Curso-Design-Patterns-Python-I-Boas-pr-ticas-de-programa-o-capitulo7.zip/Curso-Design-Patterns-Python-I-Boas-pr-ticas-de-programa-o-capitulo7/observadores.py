# -*- coding: UTF-8 -*-

def envia_por_email(nota_fiscal):
    print 'enviando nota por e-mail...'

def salva_no_banco(nota_fiscal):
    print 'salvando no banco...'        

def imprime(nota_fiscal):
    print 'imprimindo ...'
